module.exports = {
    error_emailNotExist: {
        err: "email not exist"
    },
    error_passwoardNotValid: {
        err: "password not valid"
    },
    error_emailExist : {
        err:"This emailId is already exist"
    },
    success_register : "Registeration Is Success"
}