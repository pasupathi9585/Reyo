
const Constants = {
    site_Name:"Speed Mobiles",
    nav_Menus:{
        first_Menu: "Home",
        second_Menu: "Registation",
        third_Menu: "Sales",
        fourth_Menu: "Services",
        fifth_Menu: "FeedBack"
    },
    DropMenu : {
        first_Menu: "My Profile",
        second_Menu: "Notifications",
        third_Menu: "Orders",
        forth_Menu: "Sales",
        fifth_Menu: "Sevices",
        sexth_Menu: "Sevices",
    },
    SidNavMenu : ["Samsung", "Redmi" , "Vivo", "Oppo", "Realme"]
}

export default Constants ;