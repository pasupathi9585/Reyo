import React from "react";
import { Button,Form,Navbar,Nav,FormControl, NavDropdown, Row, Col} from 'react-bootstrap';
import { } from "react-router-dom";

class Navbars extends React.Component {

    constructor(props) {
        super(props);
        this.state={
        }
    }

    redirectNav=()=>{
        window.open("/home","_self")
    }
    render() {
        return( 
        <div>
            <Navbar bg="primary" variant="dark fixed-top common-shadow">
                <Col lg={2}>
                    <Navbar.Brand href="/home">{this.props.SiteName}</Navbar.Brand>
                </Col>
                <Col lg={"auto"}>
                    <Nav className="mr-auto ">
                        <Nav.Link href="/home" active={true}>{this.props.Menus.first_Menu}</Nav.Link>
                        <Nav.Link href="/register" active={true}>{this.props.Menus.second_Menu}</Nav.Link>
                        <Nav.Link href="#" active={true}>{this.props.Menus.third_Menu}</Nav.Link>
                        <Nav.Link href="#" active={true}>{this.props.Menus.fourth_Menu}</Nav.Link>
                    </Nav>
                </Col>
                <Col lg={5}>
                    <Form className="nav_search" >
                        <FormControl  type="text" placeholder="Search" className="" />
                    </Form>
                </Col>
                <Col lg={"auto"}>
                <Nav className="mr-auto ">
                    <NavDropdown active={true} title={"Hello, " + this.props.UserName} id="basic-nav-dropdown">
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.first_Menu}</NavDropdown.Item>
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.second_Menu}</NavDropdown.Item>
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.third_Menu}</NavDropdown.Item>
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.forth_Menu}</NavDropdown.Item>
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.fifth_Menu}</NavDropdown.Item>
                        <NavDropdown.Item onClick={this.redirectNav} >{this.props.DropDown.sixth_Menu}</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item href="/login" onClick={()=>{localStorage.clear()}}>Logout</NavDropdown.Item>
                    </NavDropdown>
                </Nav>
                </Col>
            </Navbar>
        </div>

        )
    }
  }

export default Navbars